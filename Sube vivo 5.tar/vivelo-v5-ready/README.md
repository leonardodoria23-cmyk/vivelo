# Vívelo v5 - Plataforma de Experiencias Turísticas

## 🎯 Descripción

Vívelo es una plataforma de marketplace para experiencias turísticas, alojamientos y servicios en Colombia.

## ✨ Características v5

- **Home Marketplace**: Descubre experiencias, alojamientos y servicios
- **Sistema de Pago**: Bold (tarjeta/PSE), Nequi, Bancolombia
- **Flyview23 Gallery**: Galería de videos 4K profesionales
- **Admin Panel**: Gestión de proveedores y estadísticas
- **Legal Compliance**: Términos y Condiciones + Política Habeas Data (Ley 1581/2012)
- **Auth Flow**: 5 pasos (Welcome → Email → Verify → Legal → Notifications)
- **PWA-Ready**: Funciona en móvil, tablet y desktop

## 🚀 Tech Stack

- **Frontend**: React 18 + Vite
- **Styling**: Tailwind CSS 3
- **Icons**: Lucide React
- **Build**: Vite 5
- **Deployment**: Vercel

## 📦 Instalación

```bash
npm install
npm run dev      # Desarrollo
npm run build    # Producción
npm run preview  # Previsualizar build
```

## 🏃 Uso Rápido

1. Ejecuta `npm install`
2. Ejecuta `npm run dev`
3. Abre http://localhost:3000
4. Complete el flujo de auth (email: test@example.com)
5. Usa admin con: leonardo@flyview23.com o admin@vivelo.co

## 🎨 Colores Brand

- Caribbean: #0A4A52
- Orange: #FF8C42
- Yellow: #FFD60A
- Cream: #FFF8F0

## 📱 Responsivo

✓ Mobile First
✓ Tablets
✓ Desktop
✓ PWA-ready

## ✅ Checklist Pre-Launch

- [ ] Comprar dominio vivelo.co
- [ ] Configurar DNS en Vercel
- [ ] Agregar security headers (vercel.json)
- [ ] Implementar Firebase Auth
- [ ] Integrar Bold API
- [ ] Crear SAS constitution
- [ ] Testing con 10 usuarios
- [ ] Beta con 50 usuarios
- [ ] Launch público

## 📞 Contacto

- Legal: legal@vivelo.co
- Data: datos@vivelo.co
- Support: support@vivelo.co

---

**Hecho con ❤️ en Colombia** 🇨🇴
