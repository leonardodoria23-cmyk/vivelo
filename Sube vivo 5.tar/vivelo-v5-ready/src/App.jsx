import React, { useState } from 'react';
import { Home, Settings, ShoppingCart, Users, Video, Menu, X, ChevronRight, Lock, Mail, Phone, Check, AlertCircle, Download, Play, Clock, DollarSign } from 'lucide-react';

const Vivelo_v5 = () => {
  const [currentView, setCurrentView] = useState('home');
  const [authStep, setAuthStep] = useState('welcome');
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [verifyCode, setVerifyCode] = useState('');
  const [acceptTerms, setAcceptTerms] = useState(false);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState(null);
  const [reservationSummary, setReservationSummary] = useState({
    type: 'Experiencia - Jetski Santa Marta',
    price: 250000,
    date: '2026-05-10',
    quantity: 2
  });
  const [uploadedFile, setUploadedFile] = useState(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showLegalModal, setShowLegalModal] = useState(null);

  // Admin state
  const [adminPendingRequests] = useState([
    { id: 1, name: 'Hotel Boutique Costa', city: 'Santa Marta', type: 'Alojamiento', docs: 3, time: '2h ago', image: '🏨' },
    { id: 2, name: 'Pedro Fotografía', city: 'Cartagena', type: 'Servicio', docs: 2, time: '5h ago', image: '📸' },
    { id: 3, name: 'Caribbean Diving SAS', city: 'San Andrés', type: 'Experiencia', docs: 5, time: '1d ago', image: '🤿', verified: true }
  ]);
  const [adminStats] = useState({
    pendientes: 3,
    aprobadosHoy: 7,
    reservasMes: 142,
    ingresos: 8400000,
    proveedores: 87,
    usuarios: 1543
  });

  // Experiencias home
  const experiencias = [
    { id: 1, title: 'Jetski en Santa Marta', price: '250K', image: '🚤', rating: 4.9, reviews: 234, location: 'Santa Marta' },
    { id: 2, title: 'Paracaidismo Cartagena', price: '800K', image: '⛸️', rating: 4.8, reviews: 156, location: 'Cartagena' },
    { id: 3, title: 'Buceo San Andrés', price: '180K', image: '🤿', rating: 5.0, reviews: 89, location: 'San Andrés' },
    { id: 4, title: 'Tour Tayrona', price: '95K', image: '🥾', rating: 4.7, reviews: 312, location: 'Santa Marta' },
  ];

  const alojamientos = [
    { id: 1, title: 'Resort Caribeño Lujo', price: '450K/noche', image: '🏖️', rating: 4.9, location: 'Cartagena' },
    { id: 2, title: 'Casa Playa Privada', price: '320K/noche', image: '🏡', rating: 4.8, location: 'San Andrés' },
    { id: 3, title: 'Boutique Hotel Centro', price: '280K/noche', image: '🏨', rating: 4.7, location: 'Santa Marta' },
  ];

  const flyview23Videos = [
    { id: 1, title: 'Sesión Jetski + Dron 4K', status: 'ready', size: '2.3GB', quality: '4K', duration: '12:45' },
    { id: 2, title: 'Luna de Miel Cartagena', status: 'ready', size: '1.8GB', quality: '4K', duration: '18:30' },
    { id: 3, title: 'Evento Corporativo', status: 'processing', size: '3.2GB', quality: '4K', duration: '45:00', progress: 67 },
  ];

  // Render Legal Modal
  const renderLegalModal = () => {
    if (!showLegalModal) return null;
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 z-50 overflow-y-auto">
        <div className="bg-white rounded-xl max-w-2xl mx-auto my-8 p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-bold text-caribbean">{showLegalModal === 'terms' ? 'Términos y Condiciones' : 'Política de Habeas Data'}</h2>
            <button onClick={() => setShowLegalModal(null)} className="p-2 hover:bg-gray-100 rounded"><X size={24} /></button>
          </div>
          
          <div className="space-y-4 text-sm text-gray-700 max-h-96 overflow-y-auto">
            {showLegalModal === 'terms' ? (
              <>
                <div>
                  <h3 className="font-bold text-caribbean mb-2">1. Naturaleza de la Plataforma</h3>
                  <p>Vívelo es una plataforma intermediaria. No somos responsables de las acciones, omisiones, defectos o fraudes de los anfitriones o proveedores de servicios.</p>
                </div>
                <div>
                  <h3 className="font-bold text-caribbean mb-2">2. Comprobantes de Pago</h3>
                  <p>Si presentas un comprobante falso, serás baneado permanentemente y reportado a las autoridades competentes.</p>
                </div>
                <div>
                  <h3 className="font-bold text-caribbean mb-2">3. Jurisdicción</h3>
                  <p>Estos términos se rigen por las leyes de Colombia. Cualquier disputa será resuelta en los juzgados de Santa Marta.</p>
                </div>
                <div>
                  <h3 className="font-bold text-caribbean mb-2">Contacto Legal</h3>
                  <p>Email: legal@vivelo.co</p>
                </div>
              </>
            ) : (
              <>
                <div>
                  <h3 className="font-bold text-caribbean mb-2">Ley 1581 de 2012 - Colombia</h3>
                  <p>Cumplimiento de protección de datos personales según legislación colombiana.</p>
                </div>
                <div>
                  <h3 className="font-bold text-caribbean mb-2">Datos Recolectados</h3>
                  <p>Nombre, email, teléfono, comprobantes de pago, historial de reservas.</p>
                </div>
                <div>
                  <h3 className="font-bold text-caribbean mb-2">Tus Derechos</h3>
                  <p>Puedes solicitar conocer, actualizar, rectificar o revocar el uso de tus datos en cualquier momento.</p>
                </div>
                <div>
                  <h3 className="font-bold text-caribbean mb-2">Retención de Datos</h3>
                  <p>Los datos se conservan 5 años después de la eliminación de la cuenta (obligación fiscal).</p>
                </div>
                <div>
                  <h3 className="font-bold text-caribbean mb-2">Contacto DPO</h3>
                  <p>Email: datos@vivelo.co</p>
                </div>
              </>
            )}
          </div>
          
          <button onClick={() => setShowLegalModal(null)} className="mt-4 w-full btn-primary">Entendido</button>
        </div>
      </div>
    );
  };

  // AUTH FLOW
  if (authStep !== 'completed') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-caribbean via-blue-400 to-orange text-white p-4">
        <div className="max-w-md mx-auto h-screen flex flex-col justify-center items-center">
          <h1 className="text-4xl font-bold text-center mb-8">Vívelo</h1>
          
          {authStep === 'welcome' && (
            <div className="space-y-6 w-full">
              <p className="text-lg text-center">Bienvenido a las mejores experiencias de Colombia</p>
              <button onClick={() => setAuthStep('email')} className="w-full btn-primary bg-white text-caribbean">
                Crear Cuenta <ChevronRight size={20} className="inline" />
              </button>
            </div>
          )}
          
          {authStep === 'email' && (
            <div className="space-y-4 w-full">
              <input type="email" placeholder="Tu email" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full px-4 py-3 rounded-lg text-black bg-white" />
              <input type="text" placeholder="Tu nombre" value={name} onChange={(e) => setName(e.target.value)} className="w-full px-4 py-3 rounded-lg text-black bg-white" />
              <button onClick={() => setAuthStep('verify')} className="w-full btn-primary bg-white text-caribbean">Continuar</button>
            </div>
          )}
          
          {authStep === 'verify' && (
            <div className="space-y-4 w-full">
              <p className="text-sm text-center">Hemos enviado un código a {email}</p>
              <input type="text" placeholder="Código de 6 dígitos" value={verifyCode} onChange={(e) => setVerifyCode(e.target.value.slice(0, 6))} maxLength="6" className="w-full px-4 py-3 rounded-lg text-black bg-white text-center text-2xl tracking-widest" />
              <button onClick={() => setAuthStep('legal')} className="w-full btn-primary bg-white text-caribbean">Verificar</button>
            </div>
          )}
          
          {authStep === 'legal' && (
            <div className="space-y-4 w-full">
              <div className="bg-white text-caribbean p-4 rounded-lg space-y-3">
                <label className="flex items-start gap-3 cursor-pointer">
                  <input type="checkbox" checked={acceptTerms} onChange={(e) => setAcceptTerms(e.target.checked)} className="mt-1 w-5 h-5" />
                  <span className="text-sm">Acepto los <button onClick={() => setShowLegalModal('terms')} className="text-orange font-bold underline">Términos y Condiciones</button></span>
                </label>
                <label className="flex items-start gap-3 cursor-pointer">
                  <input type="checkbox" checked={acceptTerms} onChange={(e) => setAcceptTerms(e.target.checked)} className="mt-1 w-5 h-5" />
                  <span className="text-sm">He leído la <button onClick={() => setShowLegalModal('habeas')} className="text-orange font-bold underline">Política de Habeas Data</button></span>
                </label>
              </div>
              <button onClick={() => setAuthStep('notifications')} disabled={!acceptTerms} className="w-full btn-primary bg-white text-caribbean disabled:opacity-50">Continuar</button>
            </div>
          )}
          
          {authStep === 'notifications' && (
            <div className="space-y-4 w-full">
              <p className="text-sm text-center">¿Deseas recibir notificaciones?</p>
              <div className="space-y-3">
                <label className="flex items-center gap-3 cursor-pointer bg-white bg-opacity-20 p-3 rounded-lg">
                  <input type="checkbox" defaultChecked className="w-5 h-5" />
                  <span className="text-sm">Notificaciones Push (recomendado)</span>
                </label>
                <label className="flex items-center gap-3 cursor-pointer bg-white bg-opacity-20 p-3 rounded-lg">
                  <input type="checkbox" className="w-5 h-5" />
                  <span className="text-sm">Emails de marketing (máx 2/mes)</span>
                </label>
              </div>
              <button onClick={() => setAuthStep('completed')} className="w-full btn-primary bg-white text-caribbean">Listo, Empecemos!</button>
            </div>
          )}
        </div>
        {renderLegalModal()}
      </div>
    );
  }

  // MAIN APP
  return (
    <div className="min-h-screen bg-cream text-caribbean">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-3 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-caribbean">Vívelo</h1>
          <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="md:hidden">
            {mobileMenuOpen ? <X /> : <Menu />}
          </button>
          <nav className="hidden md:flex gap-6">
            <button onClick={() => setCurrentView('home')} className={`flex items-center gap-2 ${currentView === 'home' ? 'text-orange font-bold' : ''}`}>
              <Home size={20} /> Inicio
            </button>
            <button onClick={() => setCurrentView('flyview23')} className={`flex items-center gap-2 ${currentView === 'flyview23' ? 'text-orange font-bold' : ''}`}>
              <Video size={20} /> Flyview23
            </button>
            {email === 'leonardo@flyview23.com' || email === 'admin@vivelo.co' ? (
              <button onClick={() => setCurrentView('admin')} className={`flex items-center gap-2 px-3 py-1 rounded-lg ${currentView === 'admin' ? 'bg-red-500 text-white' : 'text-red-500 border border-red-500'}`}>
                <Lock size={20} /> ADMIN
              </button>
            ) : null}
          </nav>
        </div>
        {mobileMenuOpen && (
          <div className="md:hidden border-t pt-3 pb-3 px-4 space-y-2">
            <button onClick={() => { setCurrentView('home'); setMobileMenuOpen(false); }} className="block w-full text-left py-2">Inicio</button>
            <button onClick={() => { setCurrentView('flyview23'); setMobileMenuOpen(false); }} className="block w-full text-left py-2">Flyview23</button>
            {email === 'leonardo@flyview23.com' || email === 'admin@vivelo.co' ? (
              <button onClick={() => { setCurrentView('admin'); setMobileMenuOpen(false); }} className="block w-full text-left py-2 text-red-500 font-bold">ADMIN</button>
            ) : null}
          </div>
        )}
      </header>

      {/* HOME VIEW */}
      {currentView === 'home' && (
        <div className="max-w-7xl mx-auto">
          {/* Hero */}
          <div className="relative py-12 px-4 overflow-hidden">
            <svg className="absolute inset-0 w-full h-full opacity-10" viewBox="0 0 100 100">
              <path d="M0,30 Q25,10 50,30 T100,30 L100,0 L0,0 Z" fill="#FF8C42" />
            </svg>
            <div className="relative text-center">
              <h2 className="text-4xl md:text-5xl font-bold text-gradient mb-4">Vive Colombia</h2>
              <p className="text-lg text-gray-600 mb-8">Las mejores experiencias caribeñas en un solo lugar</p>
              <div className="flex gap-2 justify-center flex-wrap">
                <button className="btn-primary">Esta semana</button>
                <button className="btn-ghost">Frente al mar</button>
                <button className="btn-ghost">En oferta</button>
                <button className="btn-ghost">Instantánea</button>
              </div>
            </div>
          </div>

          {/* Experiencias */}
          <div className="px-4 py-8">
            <h3 className="text-2xl font-bold mb-6">Experiencias Populares</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {experiencias.map(e => (
                <div key={e.id} className="card p-4 cursor-pointer hover:scale-105 transition">
                  <div className="text-4xl mb-3">{e.image}</div>
                  <h4 className="font-bold mb-2">{e.title}</h4>
                  <p className="text-orange font-bold mb-2">{e.price}</p>
                  <div className="flex items-center gap-2 text-sm">
                    <span>⭐ {e.rating}</span>
                    <span>({e.reviews})</span>
                  </div>
                  <p className="text-gray-500 text-xs mt-2">{e.location}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Alojamientos */}
          <div className="px-4 py-8 bg-white bg-opacity-50">
            <h3 className="text-2xl font-bold mb-6">Alojamientos Destacados</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {alojamientos.map(a => (
                <div key={a.id} className="card p-4 cursor-pointer">
                  <div className="text-5xl mb-3">{a.image}</div>
                  <h4 className="font-bold mb-2">{a.title}</h4>
                  <p className="text-orange font-bold mb-2">{a.price}</p>
                  <div className="flex items-center gap-2 text-sm">
                    <span>⭐ {a.rating}</span>
                  </div>
                  <p className="text-gray-500 text-xs mt-2">{a.location}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Checkout Preview */}
          <div className="px-4 py-8 bg-gradient-to-r from-caribbean to-blue-600 text-white rounded-2xl mx-4 mb-8">
            <h3 className="text-2xl font-bold mb-4">Tu Reserva: {reservationSummary.type}</h3>
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div>
                <p className="text-sm opacity-75">Fecha</p>
                <p className="font-bold">{reservationSummary.date}</p>
              </div>
              <div>
                <p className="text-sm opacity-75">Cantidad</p>
                <p className="font-bold">{reservationSummary.quantity} personas</p>
              </div>
              <div>
                <p className="text-sm opacity-75">Precio/Unidad</p>
                <p className="font-bold">${reservationSummary.price.toLocaleString()} COP</p>
              </div>
              <div>
                <p className="text-sm opacity-75">Total</p>
                <p className="font-bold text-2xl">${(reservationSummary.price * reservationSummary.quantity).toLocaleString()} COP</p>
              </div>
            </div>
            <button onClick={() => setCurrentView('payment')} className="w-full bg-yellow text-caribbean font-bold py-3 rounded-lg hover:bg-orange transition">
              Proceder al Pago <ChevronRight size={20} className="inline" />
            </button>
          </div>
        </div>
      )}

      {/* FLYVIEW23 GALLERY */}
      {currentView === 'flyview23' && (
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="bg-gradient-to-r from-gray-900 via-black to-gray-900 text-white p-8 rounded-2xl mb-8">
            <h2 className="text-4xl font-bold mb-4">Galería Flyview23</h2>
            <p className="text-yellow font-bold mb-4">Tus videos profesionales en 4K</p>
            <div className="grid grid-cols-3 gap-4 text-center">
              <div><p className="text-3xl font-bold">{flyview23Videos.length}</p><p className="text-sm">Videos</p></div>
              <div><p className="text-3xl font-bold">7.3GB</p><p className="text-sm">Total</p></div>
              <div><p className="text-3xl font-bold">4K</p><p className="text-sm">Calidad</p></div>
            </div>
          </div>

          <div className="space-y-4">
            {flyview23Videos.map(v => (
              <div key={v.id} className="bg-white border-2 border-gray-200 rounded-lg p-4 flex gap-4 items-center">
                <div className="text-5xl">{v.status === 'ready' ? '▶️' : '⏳'}</div>
                <div className="flex-1">
                  <h4 className="font-bold">{v.title}</h4>
                  <p className="text-sm text-gray-600">{v.duration} • {v.size} • {v.quality}</p>
                  {v.status === 'processing' && (
                    <div className="mt-2 bg-gray-200 rounded-full h-2 w-full">
                      <div className="bg-orange h-2 rounded-full" style={{ width: `${v.progress}%` }}></div>
                    </div>
                  )}
                </div>
                {v.status === 'ready' && (
                  <div className="flex gap-2">
                    <button className="btn-primary"><Play size={18} /></button>
                    <button className="btn-secondary"><Download size={18} /></button>
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="bg-gradient-to-r from-orange to-yellow text-caribbean p-8 rounded-2xl mt-8 text-center">
            <h3 className="text-2xl font-bold mb-2">Photobook Impreso</h3>
            <p className="mb-4">Álbum de fotos profesional de tu experiencia</p>
            <button className="btn-secondary">Solicitar Photobook - $89.000 COP</button>
          </div>
        </div>
      )}

      {/* PAYMENT VIEW */}
      {currentView === 'payment' && (
        <div className="max-w-2xl mx-auto px-4 py-8">
          <h2 className="text-3xl font-bold mb-8">Selecciona Método de Pago</h2>
          
          <div className="space-y-4 mb-8">
            {[
              { id: 'bold', name: '💳 Bold (Tarjeta/PSE)', desc: 'Pago inmediato seguro', icon: '🔒' },
              { id: 'nequi', name: '📱 Nequi', desc: 'Transferencia a Carmen López 3054386395', icon: '📲' },
              { id: 'bancolombia', name: '🏦 Bancolombia', desc: 'Transferencia a cuenta 76941652120', icon: '💰' }
            ].map(method => (
              <div
                key={method.id}
                onClick={() => setSelectedPaymentMethod(method.id)}
                className={`p-4 border-2 rounded-lg cursor-pointer transition ${selectedPaymentMethod === method.id ? 'border-orange bg-orange bg-opacity-10' : 'border-gray-300'}`}
              >
                <div className="flex items-center gap-3">
                  <span className="text-3xl">{method.icon}</span>
                  <div>
                    <h3 className="font-bold">{method.name}</h3>
                    <p className="text-sm text-gray-600">{method.desc}</p>
                  </div>
                  {selectedPaymentMethod === method.id && <Check className="ml-auto text-orange" size={24} />}
                </div>
              </div>
            ))}
          </div>

          {selectedPaymentMethod === 'bold' && (
            <div className="bg-blue-50 p-6 rounded-lg mb-8">
              <p className="font-bold mb-2">Serás redirigido a Bold para completar tu pago de forma segura</p>
              <button className="w-full btn-primary">Continuar con Bold</button>
            </div>
          )}

          {(selectedPaymentMethod === 'nequi' || selectedPaymentMethod === 'bancolombia') && (
            <div className="space-y-6 mb-8">
              <div>
                <label className="block text-sm font-bold mb-2">Número de Referencia</label>
                <input type="text" placeholder="VV-2026-XXXXX" className="w-full px-4 py-2 border border-gray-300 rounded-lg" />
              </div>
              <div>
                <label className="block text-sm font-bold mb-2">Comprobante de Pago (Foto, máx 5MB)</label>
                <input 
                  type="file" 
                  accept="image/*"
                  onChange={(e) => setUploadedFile(e.target.files?.[0]?.name)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                />
                {uploadedFile && <p className="text-sm text-green-600 mt-2">✓ {uploadedFile} cargado</p>}
              </div>
              <button className="w-full btn-primary">Confirmar Pago</button>
            </div>
          )}

          <div className="bg-green-50 border border-green-200 p-6 rounded-lg">
            <h3 className="font-bold text-green-800 mb-2">✓ Confirmación de Reserva</h3>
            <p className="text-sm text-green-700">Código de confirmación: <span className="font-mono font-bold">VV-2026-8472</span></p>
            <p className="text-sm text-green-700 mt-2">Recibirás confirmación en tu email en 2 minutos</p>
          </div>
        </div>
      )}

      {/* ADMIN PANEL */}
      {currentView === 'admin' && (
        <div className="max-w-7xl mx-auto px-4 py-8">
          <h2 className="text-3xl font-bold mb-8 text-red-600">🔒 PANEL DE ADMINISTRADOR</h2>
          
          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
            <div className="bg-red-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600">Pendientes</p>
              <p className="text-3xl font-bold text-red-600">{adminStats.pendientes}</p>
            </div>
            <div className="bg-green-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600">Aprobados Hoy</p>
              <p className="text-3xl font-bold text-green-600">{adminStats.aprobadosHoy} ↑ 15%</p>
            </div>
            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600">Reservas/Mes</p>
              <p className="text-3xl font-bold text-blue-600">{adminStats.reservasMes} ↑ 22%</p>
            </div>
            <div className="bg-yellow-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600">Ingresos</p>
              <p className="text-2xl font-bold text-yellow-700">${(adminStats.ingresos/1000000).toFixed(1)}M ↑ 18%</p>
            </div>
            <div className="bg-purple-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600">Proveedores Activos</p>
              <p className="text-3xl font-bold text-purple-600">{adminStats.proveedores}</p>
            </div>
            <div className="bg-pink-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600">Usuarios</p>
              <p className="text-3xl font-bold text-pink-600">{adminStats.usuarios}</p>
            </div>
          </div>

          {/* Pending Requests */}
          <h3 className="text-2xl font-bold mb-4">Solicitudes Pendientes</h3>
          <div className="space-y-4">
            {adminPendingRequests.map(req => (
              <div key={req.id} className={`p-4 border-2 rounded-lg ${req.verified ? 'border-green-200 bg-green-50' : 'border-orange'}`}>
                <div className="flex gap-4 items-start mb-3">
                  <span className="text-4xl">{req.image}</span>
                  <div className="flex-1">
                    <h4 className="font-bold">{req.name}</h4>
                    <p className="text-sm text-gray-600">{req.type} • {req.city}</p>
                    <p className="text-xs text-gray-500 mt-1">{req.docs} documentos • {req.time}</p>
                    {req.verified && <p className="text-xs text-green-600 font-bold mt-1">✓ Verificado</p>}
                  </div>
                  {!req.verified && (
                    <div className="flex gap-2">
                      <button className="px-4 py-2 bg-red-500 text-white rounded-lg text-sm hover:bg-red-600">Rechazar</button>
                      <button className="px-4 py-2 bg-green-500 text-white rounded-lg text-sm hover:bg-green-600">Aprobar</button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-2 gap-4 mt-8">
            <button className="btn-secondary py-4">Ver Reservas</button>
            <button className="btn-secondary py-4">Ver Pagos</button>
            <button className="btn-secondary py-4">Usuarios Activos</button>
            <button className="btn-secondary py-4">Reportes</button>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="bg-caribbean text-white mt-16 py-8">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="mb-4">© 2026 Vívelo - Experiencias Turísticas en Colombia</p>
          <p className="text-sm opacity-75">legal@vivelo.co • datos@vivelo.co</p>
        </div>
      </footer>

      {renderLegalModal()}
    </div>
  );
};

export default Vivelo_v5;
